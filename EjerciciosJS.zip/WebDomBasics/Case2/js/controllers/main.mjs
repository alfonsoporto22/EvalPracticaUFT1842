export function duplicate(valor) {
    return valor*2;
}