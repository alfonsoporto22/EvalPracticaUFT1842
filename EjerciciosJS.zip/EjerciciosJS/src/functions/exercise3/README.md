# By default.

* Revisa y comprende el contenido de [example.js](example.js).
* Modifica el fichero [index.js](index.js) para conseguir una función que calcule la raíz cuadrada, a menos que se le indique otra potencia.

## Power
```javascript
5**2 // -> 25 elevado al cuadrado
2**3 // -> 8 elevado al cubo
25**(1/2) // -> 5 raíz cuadrada
8**(1/3) // -> 2 raíz cúbica
```