let number = 0;

function plusone(number_02) {
    number = number_02 + 1;
    return number;
}

plusone(5);

console.log(number);