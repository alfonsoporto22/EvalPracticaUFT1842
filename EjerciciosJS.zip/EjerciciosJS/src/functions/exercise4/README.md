# Copy or reference.

* Modifica el fichero [index.js](index.js) creando una función de nombre ```swap``` que calcule intercambie la posición de dos elementos de un array. La función se emplearía de la siguiente manera:
```javascript
const numbers = [21,22,23,24];
swap(1,3,numbers);
console.log(numbers); // -> [21,24,23,22]
```
* Observa que la función cumple su cometido incluso sin necesidad de emplear ```return```. ¿Cómo se explica esto?.