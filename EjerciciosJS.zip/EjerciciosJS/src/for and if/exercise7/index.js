const numbers = ["Frodo","Gandalf","Turin","Sauron","Saruman","Bilbo"];

for(let i=3;i<=5;i++){
    console.log(numbers[i]);
}

