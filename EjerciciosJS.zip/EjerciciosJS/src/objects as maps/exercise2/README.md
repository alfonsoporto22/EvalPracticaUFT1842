# Run

En el array `chrono` de fichero [index.js](index.js) tenemos los tiempo realizados en una carrera por los diferentes participantes. Crea una función `sort` que ordene los participantes por su tiempo, de la persona más rápida a la más lenta.


